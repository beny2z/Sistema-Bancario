package service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.List;

/** Cliente do endpoint de chat Qwen compatível com a API OpenAI. */
public final class AssistenteQwen {

    private static final String BASE_URL_PADRAO =
            "https://dashscope-intl.aliyuncs.com/compatible-mode/v1";
    private static final String MODELO_PADRAO = "qwen-plus";
    private static final String INSTRUCAO_SISTEMA = """
            Você é o assistente educacional do ThreadBank. Responda em português brasileiro, """
            + """
            com linguagem clara e concisa. Explique conceitos bancários gerais e como usar a interface. """
            + """
            Você não acessa contas, saldos, extratos ou dados do ThreadBank e não executa depósitos, """
            + """
            saques ou transferências. Não solicite senhas, códigos de autenticação, números de cartão """
            + """
            ou outros dados sigilosos. Não dê recomendação personalizada de investimento nem substitua """
            + """
            um profissional financeiro. Se o usuário enviar dados pessoais ou credenciais, recomende """
            + """
            removê-los e não os repita na resposta.
            """;

    private static final ObjectMapper JSON = new ObjectMapper();
    private static final HttpClient HTTP = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(15))
            .build();

    private final String apiKey;
    private final String baseUrl;
    private final String modelo;

    public AssistenteQwen() {
        this(System.getenv("DASHSCOPE_API_KEY"),
                System.getenv().getOrDefault("QWEN_BASE_URL", BASE_URL_PADRAO),
                System.getenv().getOrDefault("QWEN_MODEL", MODELO_PADRAO));
    }

    AssistenteQwen(String apiKey, String baseUrl, String modelo) {
        this.apiKey = apiKey == null ? "" : apiKey.trim();
        this.baseUrl = (baseUrl == null || baseUrl.isBlank() ? BASE_URL_PADRAO : baseUrl.trim())
                .replaceAll("/+$", "");
        this.modelo = modelo == null || modelo.isBlank() ? MODELO_PADRAO : modelo.trim();
    }

    public boolean estaConfigurado() {
        return !apiKey.isBlank();
    }

    /** Envia o histórico textual e devolve a resposta da primeira escolha do modelo. */
    public String responder(List<Mensagem> historico) {
        if (!estaConfigurado()) {
            throw new IllegalStateException(
                    "Configure a variável DASHSCOPE_API_KEY para habilitar o assistente Qwen.");
        }
        if (historico == null || historico.isEmpty()) {
            throw new IllegalArgumentException("Escreva uma pergunta antes de enviar.");
        }

        ObjectNode corpo = JSON.createObjectNode();
        corpo.put("model", modelo);
        corpo.put("temperature", 0.4);
        corpo.put("max_tokens", 800);
        ArrayNode mensagens = corpo.putArray("messages");
        mensagens.addObject().put("role", "system").put("content", INSTRUCAO_SISTEMA);
        for (Mensagem mensagem : historico) {
            if (!"user".equals(mensagem.role()) && !"assistant".equals(mensagem.role())) {
                throw new IllegalArgumentException("O histórico contém um papel de mensagem inválido.");
            }
            mensagens.addObject().put("role", mensagem.role()).put("content", mensagem.content());
        }

        try {
            String endpoint = baseUrl + "/chat/completions";
            HttpRequest requisicao = HttpRequest.newBuilder(URI.create(endpoint))
                    .timeout(Duration.ofSeconds(60))
                    .header("Authorization", "Bearer " + apiKey)
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(JSON.writeValueAsString(corpo)))
                    .build();
            HttpResponse<String> resposta = HTTP.send(requisicao, HttpResponse.BodyHandlers.ofString());
            if (resposta.statusCode() < 200 || resposta.statusCode() >= 300) {
                throw new IllegalStateException(mensagemErroHttp(resposta.statusCode()));
            }
            JsonNode texto = JSON.readTree(resposta.body()).path("choices").path(0)
                    .path("message").path("content");
            if (!texto.isTextual() || texto.asText().isBlank()) {
                throw new IllegalStateException("O Qwen retornou uma resposta vazia ou em formato inesperado.");
            }
            return texto.asText().trim();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("A solicitação ao Qwen foi interrompida.", e);
        } catch (IOException | IllegalArgumentException e) {
            throw new IllegalStateException(
                    "Não foi possível consultar o Qwen. Verifique a conexão e o valor de QWEN_BASE_URL.", e);
        }
    }

    private static String mensagemErroHttp(int codigo) {
        return switch (codigo) {
            case 401, 403 -> "A API recusou a chave. Confira DASHSCOPE_API_KEY e se a chave pertence à região do endpoint.";
            case 429 -> "O limite de solicitações do Qwen foi atingido. Aguarde um pouco e tente novamente.";
            case 404 -> "O endpoint ou modelo Qwen não foi encontrado. Confira QWEN_BASE_URL e QWEN_MODEL.";
            default -> "O serviço Qwen retornou HTTP " + codigo + ". Tente novamente mais tarde.";
        };
    }

    public record Mensagem(String role, String content) {
        public Mensagem {
            if (role == null || content == null) {
                throw new IllegalArgumentException("A mensagem precisa ter papel e conteúdo.");
            }
        }
    }
}
