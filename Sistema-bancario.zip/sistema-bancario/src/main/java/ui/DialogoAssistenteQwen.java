package ui;

import service.AssistenteQwen;

import javax.swing.BorderFactory;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingWorker;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

/** Janela de chat educacional com o modelo Qwen. */
public final class DialogoAssistenteQwen extends JDialog {

    private final AssistenteQwen assistente = new AssistenteQwen();
    private final List<AssistenteQwen.Mensagem> historico = new ArrayList<>();
    private final JTextArea conversa = new JTextArea();
    private final JTextField entrada = new JTextField();
    private final BotaoApp enviar = new BotaoApp("Enviar", BotaoApp.Estilo.PRIMARIO);

    public DialogoAssistenteQwen(JanelaPrincipal dono) {
        super(dono, "Assistente Qwen", true);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        JPanel raiz = new JPanel(new BorderLayout(0, 12));
        raiz.setBackground(Tema.FUNDO);
        raiz.setBorder(BorderFactory.createEmptyBorder(20, 20, 18, 20));

        JPanel topo = new JPanel(new BorderLayout(0, 6));
        topo.setOpaque(false);
        javax.swing.JLabel titulo = new javax.swing.JLabel("Assistente Qwen");
        titulo.setFont(Tema.fonte(java.awt.Font.BOLD, 20f));
        titulo.setForeground(Tema.BRANCO);
        javax.swing.JLabel aviso = new javax.swing.JLabel(assistente.estaConfigurado()
                ? "Tire dúvidas gerais sobre o uso e conceitos bancários."
                : "Configure DASHSCOPE_API_KEY para habilitar as respostas.");
        aviso.setFont(Tema.fonte(java.awt.Font.PLAIN, 12f));
        aviso.setForeground(Tema.CINZA);
        topo.add(titulo, BorderLayout.NORTH);
        topo.add(aviso, BorderLayout.SOUTH);
        raiz.add(topo, BorderLayout.NORTH);

        conversa.setEditable(false);
        conversa.setLineWrap(true);
        conversa.setWrapStyleWord(true);
        conversa.setFont(Tema.fonte(java.awt.Font.PLAIN, 14f));
        conversa.setForeground(Tema.BRANCO);
        conversa.setBackground(Tema.SUPERFICIE);
        conversa.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        JScrollPane rolagem = new JScrollPane(conversa);
        Tema.estilizar(rolagem);
        raiz.add(rolagem, BorderLayout.CENTER);

        JPanel rodape = new JPanel(new BorderLayout(8, 0));
        rodape.setOpaque(false);
        entrada.setFont(Tema.fonte(java.awt.Font.PLAIN, 14f));
        entrada.setForeground(Tema.BRANCO);
        entrada.setCaretColor(Tema.ROXO_CLARO);
        entrada.setBackground(Tema.SUPERFICIE_ALTA);
        entrada.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Tema.SUPERFICIE_ALTA),
                BorderFactory.createEmptyBorder(8, 10, 8, 10)));
        rodape.add(entrada, BorderLayout.CENTER);
        rodape.add(enviar, BorderLayout.EAST);
        raiz.add(rodape, BorderLayout.SOUTH);

        setContentPane(raiz);
        setMinimumSize(new Dimension(390, 540));
        setSize(430, 620);
        setLocationRelativeTo(dono);
        enviar.addActionListener(e -> enviarMensagem());
        entrada.addActionListener(e -> enviarMensagem());
        conversa.setText("Qwen: Olá! Posso explicar conceitos bancários gerais e ajudar com dúvidas sobre a interface.\n"
                + "Não envie senhas, códigos de autenticação, CPF ou dados de cartão.\n\n");
    }

    public void abrir() {
        setVisible(true);
    }

    private void enviarMensagem() {
        String texto = entrada.getText().trim();
        if (texto.isEmpty() || !enviar.isEnabled()) {
            return;
        }
        entrada.setText("");
        historico.add(new AssistenteQwen.Mensagem("user", texto));
        apararHistorico();
        conversa.append("Você: " + texto + "\n\nQwen: ");
        entrada.setEnabled(false);
        enviar.setEnabled(false);

        new SwingWorker<String, Void>() {
            @Override
            protected String doInBackground() {
                return assistente.responder(List.copyOf(historico));
            }

            @Override
            protected void done() {
                try {
                    String resposta = get();
                    historico.add(new AssistenteQwen.Mensagem("assistant", resposta));
                    conversa.append(resposta + "\n\n");
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    conversa.append("A solicitação foi interrompida.\n\n");
                } catch (ExecutionException e) {
                    Throwable causa = e.getCause();
                    conversa.append((causa == null ? "Falha ao consultar o assistente."
                            : causa.getMessage()) + "\n\n");
                } finally {
                    entrada.setEnabled(true);
                    enviar.setEnabled(true);
                    entrada.requestFocusInWindow();
                }
            }
        }.execute();
    }

    private void apararHistorico() {
        while (historico.size() > 12) {
            historico.remove(0);
            if (!historico.isEmpty() && "assistant".equals(historico.get(0).role())) {
                historico.remove(0);
            }
        }
    }
}
