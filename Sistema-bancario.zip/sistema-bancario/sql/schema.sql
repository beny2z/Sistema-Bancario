-- ThreadBank — esquema para MySQL 8.0.16 ou superior.
-- O banco threadbank deve ser criado previamente; as tabelas podem ser criadas novamente com segurança.

CREATE TABLE IF NOT EXISTS contas (
    numero        BIGINT        PRIMARY KEY,
    titular_nome  VARCHAR(120)  NOT NULL,
    titular_cpf   VARCHAR(11)   NOT NULL,
    saldo         DECIMAL(15,2) NOT NULL,
    CONSTRAINT chk_contas_saldo CHECK (saldo >= 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS transacoes (
    id                 BIGINT        NOT NULL AUTO_INCREMENT PRIMARY KEY,
    numero_conta       BIGINT        NOT NULL,
    tipo               VARCHAR(30)   NOT NULL,
    valor              DECIMAL(15,2) NOT NULL,
    horario            TIMESTAMP     NOT NULL,
    conta_contraparte  BIGINT        NULL,
    CONSTRAINT chk_transacoes_valor CHECK (valor > 0),
    CONSTRAINT fk_transacoes_contas FOREIGN KEY (numero_conta) REFERENCES contas (numero),
    INDEX idx_transacoes_conta (numero_conta, id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
