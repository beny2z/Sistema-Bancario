# ThreadBank — Sistema Bancário com Transações Concorrentes

Aplicação desktop em Java 25+ com interface Swing, JDBC e persistência MySQL. O sistema demonstra operações bancárias concorrentes, transferências atômicas, extrato e integração opcional com o assistente Qwen.

## Requisitos

- Java 25 ou superior e Maven 3.8+.
- MySQL 8.0.16 ou superior, com acesso JDBC e suporte a `CHECK` constraints.
- Para usar o assistente: uma chave de API do Alibaba Cloud Model Studio/DashScope válida para a região configurada.

## Configurar o MySQL

Crie o banco e um usuário próprio para a aplicação. Exemplo para um ambiente local:

```sql
CREATE DATABASE threadbank CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
CREATE USER 'threadbank_app'@'localhost' IDENTIFIED BY 'troque-esta-senha';
GRANT ALL PRIVILEGES ON threadbank.* TO 'threadbank_app'@'localhost';
```

Configure a conexão por variáveis de ambiente. Não grave usuário ou senha no código-fonte:

```bash
export DB_URL='jdbc:mysql://localhost:3306/threadbank?serverTimezone=UTC'
export DB_USER='threadbank_app'
export DB_PASSWORD='troque-esta-senha'
```

O banco `threadbank` precisa existir antes de iniciar o programa. As tabelas são criadas automaticamente com base em `src/main/resources/schema.sql`; o script também está disponível em `sql/schema.sql` para execução manual. Os dados passam a ficar no MySQL, e não em arquivos locais.

## Configurar Qwen

O assistente usa a API de chat compatível com OpenAI do Model Studio. Crie uma chave de API na mesma região do endpoint e configure-a no ambiente:

```bash
export DASHSCOPE_API_KEY='sua-chave-de-api'
# Opcional: endpoint regional/base URL do seu workspace no Model Studio
export QWEN_BASE_URL='https://dashscope-intl.aliyuncs.com/compatible-mode/v1'
# Opcional; padrão: qwen-plus
export QWEN_MODEL='qwen-plus'
```

O endpoint internacional mostrado é um padrão inicial compatível; use o endpoint regional/workspace e a chave correspondentes à sua conta quando necessário. A aplicação envia ao provedor somente as mensagens digitadas na conversa do assistente. Ela não anexa saldos, extratos, CPFs ou informações de conta ao pedido. O histórico existe apenas enquanto a janela de chat está aberta. Não envie credenciais, códigos de autenticação ou dados de cartão.

A documentação oficial da API está em [Qwen OpenAI-compatible Chat](https://www.alibabacloud.com/help/en/model-studio/qwen-api-via-openai-chat-completions) e [Model Studio OpenAI compatibility](https://www.alibabacloud.com/help/en/model-studio/compatibility-of-openai-with-dashscope).

## Executar

```bash
mvn test                                  # testes locais e integração MySQL se DB_TEST_URL estiver configurado
mvn compile exec:java                     # abre a interface Swing (app/AppBancario)
mvn compile
java -cp target/classes app.Main          # simulação em console
java -cp target/classes app.DeadlockDemo  # deadlock demonstrativo e transferência segura
```

Para abrir a interface pela IDE, importe o projeto como Maven e execute `app.AppBancario`. Na primeira execução, se o banco estiver vazio, são criadas três contas de exemplo. Novas contas ficam disponíveis imediatamente na lista e também como destino no diálogo de depósito.

## Testes de integração MySQL

Os testes de repositório e de `BancoService` usam MySQL real e são ignorados por padrão quando `DB_TEST_URL` não está definido. Para executá-los, crie um banco isolado, por exemplo `threadbank_test`, e configure:

```bash
export DB_TEST_URL='jdbc:mysql://localhost:3306/threadbank_test?serverTimezone=UTC'
export DB_TEST_USER='threadbank_test'
export DB_TEST_PASSWORD='senha-do-banco-de-teste'
mvn test
```

A suíte apaga o conteúdo das tabelas `transacoes` e `contas` no banco indicado antes de cada teste. **Nunca configure `DB_TEST_URL` para apontar ao banco com dados reais.** Os demais testes unitários não precisam de servidor MySQL.

## Estrutura

```text
src/main/java/
  domain/       Cliente, Conta, Transacao, tipos e exceções de negócio
  persistence/  interfaces de repositório e unidade de trabalho
    jdbc/       ConnectionFactory, JdbcSessao e repositórios JDBC para MySQL
    memory/     repositórios em memória usados por testes unitários
  service/      BancoService e cliente HTTP AssistenteQwen
  ui/           telas Swing, operações e diálogo de chat Qwen
  simulacao/    operações concorrentes e simulações
  io/           formatação monetária e exportação de extrato
  app/          pontos de entrada do aplicativo e demos
src/main/resources/schema.sql   esquema MySQL carregado pela aplicação
sql/schema.sql                  cópia do esquema para execução manual
```

## Funcionalidades e mudanças

- **Depósito em qualquer conta:** o diálogo lista todas as contas registradas, incluindo contas recém-abertas. A conta ativa vem pré-selecionada, mas o usuário pode escolher outro destino.
- **Assistente Qwen:** novo botão na tela principal abre um chat educacional. As chamadas HTTP são assíncronas para a interface não congelar; endpoint, modelo e chave são configurados por ambiente. O assistente não opera a conta nem recebe dados bancários do sistema.
- **MySQL como único banco:** a aplicação usa MySQL por padrão via Connector/J. O esquema foi ajustado para InnoDB, `AUTO_INCREMENT`, chaves estrangeiras, índices e restrições de saldo/valor; dependências, drivers e arquivos anteriores foram removidos.
- **Testes de persistência:** os testes JDBC foram convertidos para integração opcional com um banco MySQL de teste dedicado; os testes unitários permanecem executáveis sem MySQL.

## Arquitetura e regras de negócio

`domain` não conhece a interface nem a persistência. `BancoService` coordena as regras de `Conta` e os repositórios. A gravação acontece sob os mesmos bloqueios usados para alterar o saldo em memória; transferências bloqueiam as contas em ordem global e gravam saldos e movimentações na mesma transação JDBC. Em caso de falha, o rollback do banco é acompanhado pela reversão da memória.

O dinheiro é representado por `BigDecimal` com duas casas. `Transacao` e `Cliente` são imutáveis. O saldo inicial positivo também entra no extrato como depósito, de modo que o total do extrato corresponda ao saldo.

A garantia de sincronização do serviço vale dentro de uma JVM. Se várias instâncias do aplicativo escreverem nas mesmas contas simultaneamente, é necessário acrescentar bloqueio/controle de concorrência no banco (por exemplo, `SELECT ... FOR UPDATE` ou versionamento otimista).
