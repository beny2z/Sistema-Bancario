package persistence.jdbc;

import persistence.PersistenciaException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Cria conexões JDBC e prepara o banco. Não tem nenhuma regra bancária.
 * A aplicação e os testes de integração usam MySQL.
 */
public class ConnectionFactory {

    private final String url;
    private final String usuario;
    private final String senha;

    public ConnectionFactory(String url, String usuario, String senha) {
        this.url = url;
        this.usuario = usuario;
        this.senha = senha;
    }

    /** MySQL configurado por ambiente; não mantém credenciais no código-fonte. */
    public static ConnectionFactory mysqlPorAmbiente() {
        String url = System.getenv().getOrDefault("DB_URL",
                "jdbc:mysql://localhost:3306/threadbank?serverTimezone=UTC");
        String usuario = System.getenv().getOrDefault("DB_USER", "root");
        String senha = System.getenv().getOrDefault("DB_PASSWORD", "");
        return new ConnectionFactory(url, usuario, senha);
    }

    /** MySQL de integração configurado separadamente para evitar atingir o banco da aplicação. */
    public static ConnectionFactory mysqlDeTeste() {
        String url = System.getenv("DB_TEST_URL");
        if (url == null || !url.startsWith("jdbc:mysql:")) {
            throw new IllegalStateException("Configure DB_TEST_URL com um banco MySQL isolado para os testes.");
        }
        String usuario = System.getenv().getOrDefault("DB_TEST_USER", "root");
        String senha = System.getenv().getOrDefault("DB_TEST_PASSWORD", "");
        return new ConnectionFactory(url, usuario, senha);
    }

    public Connection abrir() throws SQLException {
        return DriverManager.getConnection(url, usuario, senha);
    }

    /** Executa o script schema.sql (do classpath). Seguro de repetir: usa IF NOT EXISTS. */
    public void criarTabelas() {
        try (InputStream in = ConnectionFactory.class.getResourceAsStream("/schema.sql")) {
            if (in == null) {
                throw new PersistenciaException("schema.sql não encontrado no classpath", null);
            }
            StringBuilder sql = new StringBuilder();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
                String linha;
                while ((linha = r.readLine()) != null) {
                    if (!linha.trim().startsWith("--")) {
                        sql.append(linha).append('\n');
                    }
                }
            }
            try (Connection c = abrir(); Statement st = c.createStatement()) {
                for (String comando : sql.toString().split(";")) {
                    if (!comando.isBlank()) {
                        st.execute(comando);
                    }
                }
            }
        } catch (IOException | SQLException e) {
            throw new PersistenciaException("Falha ao criar as tabelas", e);
        }
    }
}
