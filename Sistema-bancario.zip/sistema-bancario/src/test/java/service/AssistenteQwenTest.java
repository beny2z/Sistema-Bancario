package service;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class AssistenteQwenTest {

    @Test
    void indicaQuandoAChaveNaoFoiConfigurada() {
        AssistenteQwen assistente = new AssistenteQwen("", "https://example.test/v1", "qwen-plus");

        assertFalse(assistente.estaConfigurado());
        IllegalStateException erro = assertThrows(IllegalStateException.class,
                () -> assistente.responder(List.of(new AssistenteQwen.Mensagem("user", "Olá"))));
        assertTrue(erro.getMessage().contains("DASHSCOPE_API_KEY"));
    }

    @Test
    void consideraChaveConfiguradaQuandoNaoEstaEmBranco() {
        AssistenteQwen assistente = new AssistenteQwen("teste", "https://example.test/v1", "qwen-plus");

        assertTrue(assistente.estaConfigurado());
    }
}
